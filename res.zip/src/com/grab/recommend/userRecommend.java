package com.grab.recommend;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.grab.database.DataB;

public class userRecommend {
	static DataB db = new DataB();
	public static Map<String,Double> getUserRecommendation(String user)
	{
		Map<String,Double> ratings = db.getUserRatings(user);
		Map<Integer,String> totalMovie=db.getMovie();
		List<Integer> unwatchedMovie = new ArrayList<Integer>();
		List<String> watched = new ArrayList<String>();
		Map<String,Double> predicted = new HashMap<String,Double>();
		Double avg=0.0,total=0.0;
		int count=0;
		
		for(Double d : ratings.values())
		{
			total=total+d;
			count=count+1;
		}
		if(count!=0)
			avg=total/count;
		else
			avg=0.0;
		for(Integer key:totalMovie.keySet())
		{
			if(!ratings.containsKey(key+""))
			{
				unwatchedMovie.add(key);
			}
			else
				watched.add(key+"");
		}
		for(Integer key:unwatchedMovie)
		{
			Map<String,Double> simi= db.getHybridRecommendatin(key+"");
			double prod=1.0;
			double sum =0,result=0;
			for(String s: watched)
			{
				Double rat =ratings.getOrDefault(s, avg);
				Double wm=simi.getOrDefault(s, 0.1);
				System.out.println(rat+"aa"+wm);
				prod=prod+rat*wm;
				sum+=wm;
			}
			if(sum!=0)
			{
				result=prod/sum;
			}else
			{
				result=0;
			}
			predicted.put(key+"", result);
			
		}
		predicted=db.sortByValue(predicted);
		return predicted;
		
	}
	public static void main(String[] args)
	{
		Map<String,Double> pred=getUserRecommendation("2");
		for(String s : pred.keySet())
		{
			System.out.println(s+"..."+pred.get(s));
		}
	}

}
