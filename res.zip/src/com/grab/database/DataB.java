package com.grab.database;

import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;


public class DataB {
	Connection conn=null;
	Map<Integer,String> movie;
	String sql;
	public DataB() {
		try {
		Class.forName("com.mysql.jdbc.Driver");  
		conn =DriverManager.getConnection("jdbc:mysql://localhost/grab","root","");
		
		}catch(Exception a) {
			System.out.println("Error In connection");
			}
	}
	
	public boolean login(String user, String pass)
	{
		sql = "select * from login where name='"+user+"' and password='"+pass+"'";
		PreparedStatement pstmt;
		try {
			pstmt = conn.prepareStatement(sql);
			ResultSet rs = pstmt.executeQuery();

			if(rs.next())
			{
				return true;
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return false;
			
	}
	public boolean register(String user, String pass)
	{
		 String sql = "insert into login values (?, ? , ?,?)";
			PreparedStatement pstmt;
			try {
				pstmt = conn.prepareStatement(sql);
				if(user.length()==0 && pass.length()==0) {
					return false;
				
				}else {
					pstmt.setString(1,null);
					pstmt.setString(2, user);
					pstmt.setString(3, pass);
					pstmt.setInt(4, 0);
					pstmt.executeUpdate();
					
					return true;
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		return false;
	}


	public Map<String,Double> getPearsonRecommendation(String movie)
	{
		sql="Select movie2 from cosine where movie1="+movie;
		Map<String,Double> recom = new HashMap<String, Double>();
		PreparedStatement pstmt;
		try {
			pstmt=conn.prepareStatement(sql);
			ResultSet rs= pstmt.executeQuery();
			while(rs.next())
			{
				recom.put(rs.getString(3),rs.getDouble(4));
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		return recom;
	}
	public List<String[]> getPearson()
	{
		sql="Select * from pearson ";
		List<String[]> recom = new ArrayList<String[]>();
		PreparedStatement pstmt;
		try {
			pstmt=conn.prepareStatement(sql);
			ResultSet rs= pstmt.executeQuery();
			while(rs.next())
			{
				
					String[] st = new String[3];
					st[0]=rs.getString("movie1");
					st[1]=rs.getString("movie2");
					st[2]=rs.getString("similarity");
					recom.add(st);
				
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		return recom;
	}
	public List<String[]> getCosine()
	{
		sql="Select * from cosine ";
		List<String[]> recom = new ArrayList<String[]>();
		PreparedStatement pstmt;
		try {
			pstmt=conn.prepareStatement(sql);
			ResultSet rs= pstmt.executeQuery();
			while(rs.next())
			{
				
					String[] st = new String[3];
					st[0]=rs.getString("movie1");
					st[1]=rs.getString("movie2");
					st[2]=rs.getString("similarity");
					recom.add(st);
				
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		return recom;
	}
	public Map<String,Double> getCosineRecommendation(String movie)
	{
		sql="Select movie2 from cosine where movie1="+movie;
		Map<String,Double> recom = new HashMap<String, Double>();
		PreparedStatement pstmt;
		try {
			pstmt=conn.prepareStatement(sql);
			ResultSet rs= pstmt.executeQuery();
			while(rs.next())
			{
				recom.put(rs.getString(3),rs.getDouble(4));
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		return recom;
	}
	public Map<String,Double> getHybridRecommendatin(String movie)
	{
		sql="Select movie2,similarity from hybrid where movie1="+movie;
		//System.out.println(movie);
		Map<String,Double> recom= new LinkedHashMap<String, Double>();
		PreparedStatement pstmt;
		try {
			pstmt=conn.prepareStatement(sql);
			ResultSet rs= pstmt.executeQuery();
			while(rs.next())
			{
				
				recom.put(rs.getString("movie2"),rs.getDouble("similarity"));
			}
		}catch(Exception e)
		{
			System.out.println("error");
			e.printStackTrace();
		}
		
		return recom;
	}
	
	public List<String[]> getMovieDetails()
	{
		List<String[]> moviefeatures = new ArrayList<String[]>();
		sql = "Select * from moviedetails";
		
		PreparedStatement pstmt;
		try {
			pstmt = conn.prepareStatement(sql);
			ResultSet rs = pstmt.executeQuery();
			
			while(rs.next())
			{
				
				
					String[] mm = new String[8];
					mm[0]=rs.getString("movieId");
					mm[1]=rs.getString("movieName");
					mm[2]=rs.getString("genre");
					mm[3]=rs.getString("langugae");
					mm[4]=rs.getString("date");
					mm[5]=rs.getString("country");
					mm[6]=rs.getString("description");
					mm[7]=rs.getString("popularity");
					moviefeatures.add(mm);
				
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return moviefeatures;
	}
	
	
	public Map<Integer,String> getMovie()
	{
		Map<Integer,String> movie = new HashMap<Integer, String>();
		sql = "Select movieId,movieName from movie";
		
		PreparedStatement pstmt;
		try {
			pstmt = conn.prepareStatement(sql);
			ResultSet rs = pstmt.executeQuery();
			
			while(rs.next())
			{
				
				movie.put(rs.getInt("movieId"),rs.getString("movieName"));
				
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return movie;
	}
	public String getMName(Integer id)
	{
		sql = "Select movieName from movie where movieId="+id;
		
		PreparedStatement pstmt;
		try {
			pstmt = conn.prepareStatement(sql);
			ResultSet rs = pstmt.executeQuery();
			
			if(rs.next())
			{
				
				return rs.getString("movieName");
				
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "not available";
	}
	public String getMid(String name)
	{
		sql = "Select movieId from movie where movieName = "+name;
		System.out.println("yo");
		PreparedStatement pstmt;
		try {
			pstmt = conn.prepareStatement(sql);
			ResultSet rs = pstmt.executeQuery();
			
			if(rs.next())
			{
				System.out.println(rs.getString("movieid"));
				return rs.getString("movieId");
				
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "-1";
	}

	public void updateGenre(String user, String genre)
	{
	sql="UPDATE userprofile SET genre = ? WHERE id = ?";
	PreparedStatement ps;
	try {
		ps = conn.prepareStatement(sql);

    ps.setString(1,genre);
    ps.setString(2,user);

    // call executeUpdate to execute our sql update statement
    ps.executeUpdate();
    
	}
	catch(Exception e)
	{
		e.printStackTrace();
	}
	
	}

	public void updateLanguage(String user, String lang)
	{
	sql="UPDATE userprofile SET language = ? WHERE id = ?";
	PreparedStatement ps;
	try {
		ps = conn.prepareStatement(sql);

    ps.setString(1,lang);
    ps.setString(2,user);

    // call executeUpdate to execute our sql update statement
    ps.executeUpdate();
    
	}catch(Exception e)
	{
		e.printStackTrace();
	}
	}

	public void updateCountry(String user, String country)
	{
	sql="UPDATE userprofile SET country = ? WHERE id = ?";
	PreparedStatement ps;
	try {
		ps = conn.prepareStatement(sql);

    ps.setString(1,country);
    ps.setString(2,user);

    // call executeUpdate to execute our sql update statement
    ps.executeUpdate();
    
	}
	catch(Exception e)
	{
		e.printStackTrace();
	}
	}

	public void updateYear(String user, String year)
	{
	sql="UPDATE userprofile SET year = ? WHERE id = ?";
	PreparedStatement ps;
	try {
		ps = conn.prepareStatement(sql);

    ps.setString(1,year);
    ps.setString(2,user);

    // call executeUpdate to execute our sql update statement
    ps.executeUpdate();
    
	}
	catch(Exception e)
	{
		e.printStackTrace();
	}
	
	}
	public void updateFeatures(String user, String genre, String lang,String country, String year)
	{
	sql="UPDATE userprofile SET genre = ?, language = ?, country= ?,year =?  WHERE id = ?";
	PreparedStatement ps;
	try {
		ps = conn.prepareStatement(sql);

    ps.setString(1,genre);
    ps.setString(2,lang);
    ps.setString(3,country);
    ps.setString(4,year);
    ps.setString(5,user);
    // call executeUpdate to execute our sql update statement
    ps.executeUpdate();
    
	}
	catch(Exception e)
	{
		e.printStackTrace();
	}
	
	}
	public int getGenre(String user) {
		sql="Select genre from userprofile where id = "+2;
		PreparedStatement ps;
		try {
			ps = conn.prepareStatement(sql);
			ResultSet rs =ps.executeQuery();
			if(rs.next())
			{
				String gen=rs.getString("genre");
				return this.getGenreId(gen);
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return 15;
	}
	public List<String> getHistory(String user)
	{
		sql="Select movieId from ratings where userId ="+ user;
		List<String> watched = new ArrayList<String>();
		PreparedStatement ps;
		try {
			ps = conn.prepareStatement(sql);
			ResultSet rs =ps.executeQuery();
			while(rs.next())
			{
				watched.add(rs.getString("movieid"));
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return watched;
	}
	public List<String> getLiked(String user)
	{
		sql="select movieId from ratings where userId="+user+" and rating>3";
		List<String> watched = new ArrayList<String>();
		PreparedStatement ps;
		try {
			ps = conn.prepareStatement(sql);
			ResultSet rs =ps.executeQuery();
			while(rs.next())
			{
				watched.add(rs.getString("movieId"));
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return watched;
	}
	public List<String> getTrending()
	{
		sql="select movieId,popularity from moviedetails where popularity>10";
		Map<String,Double> trending = new HashMap<String,Double>();
		List<String> sortedTrending = new ArrayList<String>();
		
		PreparedStatement ps;
		try {
			ps = conn.prepareStatement(sql);
			ResultSet rs =ps.executeQuery();
			while(rs.next())
			{
				
				trending.put(rs.getString("movieId"),rs.getDouble("popularity"));
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Map<String,Double> trend = this.sortByValue(trending);
		for(String s: trend.keySet())
		{
			sortedTrending.add(s);
		}
		return sortedTrending;
	}

	public List<String> getMoviesByGenre(int genre)
	{
//Ranking garne sab ma
		sql="select movieName,genre from moviedetails ";
		List<String >movs = new ArrayList<String>();
		PreparedStatement ps;
		try {
			ps = conn.prepareStatement(sql);
			ResultSet rs =ps.executeQuery();
			while(rs.next())
			{
				String gen=rs.getString("genre");
				if(gen.charAt(genre+1)=='1')
				{
					movs.add(rs.getString("movieName"));
				}
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		return movs;
		}
	public boolean updateRating(String user, String movie, double rating)
	{
		sql="Update ratings set rating= "+rating+" where userId = "+user+" and movieId="+movie;
		PreparedStatement ps;
		try {
			ps = conn.prepareStatement(sql);
			
			int rs =ps.executeUpdate();
			if(rs>0)
			{
				return true;
			}
			else
			{
				this.addRating(user,movie,  rating);
				return true;
			}
			
			}catch(Exception e)
			{
				e.printStackTrace();
			}
		return false; 
	}
	public boolean addRating(String user, String movie2, double rating) {
		sql="Insert into ratings (userId,movieId,rating) values ("+user+","+movie2+","+rating+")";
		PreparedStatement ps;
		try {
			System.out.println(sql);
			ps = conn.prepareStatement(sql);
			int rs =ps.executeUpdate();
			if(rs>0)
			{
				return true;
			}
			else {
				this.updateRating(user, movie2, rating);
					return true;
			}
			}catch(Exception e)
			{
				e.printStackTrace();
			}
		return false; 
		
	}

	public  Map<String, Double> sortByValue(Map<String, Double> unsortMap) {

       
        List<Map.Entry<String,Double>> list =
                new LinkedList<Map.Entry<String,Double>>(unsortMap.entrySet());

       
        Collections.sort(list, new Comparator<Map.Entry<String,Double>>() {
            public int compare(Map.Entry<String,Double> o1,
                               Map.Entry<String,Double> o2) {
                return (o1.getValue()).compareTo(o2.getValue());
            }
        });
        
        Collections.reverse(list);
      
        Map<String, Double> sortedMap = new LinkedHashMap<String, Double>();
        for (Map.Entry<String,Double> entry : list) {
            sortedMap.put(entry.getKey(), entry.getValue());
        }

        return sortedMap;
    }
	public Map<String,Double> getUserRatings(String user)
	{
		Map<String,Double> userRatings = new HashMap<String,Double>();
		sql= "Select movieId, rating from ratings where userId = "+user;
		PreparedStatement ps;
		try {
			ps = conn.prepareStatement(sql);
			ResultSet rs =ps.executeQuery();
			while(rs.next())
			{
				userRatings.put(rs.getString("movieId"), rs.getDouble("rating"));
			}
			
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
		return userRatings;
		
	}

	public List<String[]> getMoviebyRatings() {
		List<String[]> movies = new ArrayList<String[]>();
		
		sql="select * from ratings ";
		PreparedStatement ps;
		try {
			ps = conn.prepareStatement(sql);
			ResultSet rs =ps.executeQuery();
			while(rs.next())
			{
				String[] mm= new String[3];
				mm[0]=rs.getString("userId");
				mm[1]=rs.getString("movieId");
				mm[2]=rs.getString("ratings");
				movies.add(mm);
			}
			//System.out.println(movies.get(0)[0]+"a"+movies.get(50)[0]);
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
		return movies;
	}

	public List<String> getRankedHybridRecommendation(String string) {
		Map<String,Double> movs = this.getHybridRecommendatin(string);
		Map<String,Double> mov = this.sortByValue(movs);
		for(String s :mov.keySet())
		{
		System.out.println(mov.get(s));
	}
		 while (mov.values().remove(1.0));
		List<String> ls=new ArrayList<String>();
		for(String i: mov.keySet())
		{
			ls.add(i);
		}
		return ls;
	}

	public String getMoveDescription(String mv) {
		String desc="";
		sql = "Select description from moviedetails where movieId="+mv;
		
		PreparedStatement pstmt;
		try {
			pstmt = conn.prepareStatement(sql);
			ResultSet rs = pstmt.executeQuery();
			
			if(rs.next())
			{
				
				desc=rs.getString("description");
				
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return desc;
	}
	public int getGenreId(String gen)
	{
	
		  switch(gen)
		  {
		  case "Action":
			  return 0;
			  
		  case "Animation":
			  return 1;
			  
		  case "Comedy":
			  return 2;
			  
		  case "Family":
			  return 3;
			  
		  case "Adventure":
			  return 4;
			  
		  case "Fantasy":
			  return 5;
			  
		  case "Romance":
			  return 6;
			  
		  case "Drama":
			  return 7;
			  
		  case "Thriller":
			  return 8;
			  
		  case "Horror":
			  return 9;
			  
		  case "History":
			  return 10;
			  
		  case "Crime":
			  return 11;
			  
		  case "Science Fiction":
			  return 12;
			  
		  case "Documentary":
			  return 13;
			  
		  case "War":
			  return 14;
			  
		  default:
			  return 15;
		  }
	}
	public boolean addCosine(int i, String m1,String m2, Double val)
	{
		sql="Insert into cosine values ( "+i+","+m1+","+m2+","+val+")";
		PreparedStatement ps;
		try {
			ps = conn.prepareStatement(sql);

	
	    int rs = ps.executeUpdate(sql);
	    if(rs>0)
	    {
	    	return true;
	    }
	    else
	    	return false;
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		return false;
		
	}

	public boolean addPearson(int i, String m1,String m2, Double val)
	{
		 sql="Insert into pearson values ( "+i+","+m1+","+m2+","+val+")";
		PreparedStatement ps;
		try {
			ps = conn.prepareStatement(sql);

	
	    int rs = ps.executeUpdate(sql);
	    if(rs>0)
	    {
	    	return true;
	    }
	    else
	    	return false;
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		return false;
	}
	public boolean addHybrid(int i, String m1,String m2, Double val)
	{
		 sql="Insert into hybrid values ( "+i+","+m1+","+m2+","+val+")";
		PreparedStatement ps;
		try {
			ps = conn.prepareStatement(sql);

	
	    int rs = ps.executeUpdate(sql);
	    if(rs>0)
	    {
	    	return true;
	    }
	    else
	    	return false;
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		return false;
	}
//	public void insert(String user,String columnHead)
//	{
//		sql="Insert into userprofile "
//	}
	public Map<String,Double> getUserRecommendation(String user)
	{
		Map<String,Double> ratings = getUserRatings(user);
		Map<Integer,String> totalMovie=getMovie();
		List<Integer> unwatchedMovie = new ArrayList<Integer>();
		List<String> watched = new ArrayList<String>();
		Map<String,Double> predicted = new HashMap<String,Double>();
		Double avg=0.0,total=0.0;
		int count=0;
		
		for(Double d : ratings.values())
		{
			total=total+d;
			count=count+1;
		}
		if(count!=0)
			avg=total/count;
		else
			avg=0.0;
		System.out.println(avg);
		for(Integer key:totalMovie.keySet())
		{
			//System.out.println("tt="+key);
			if(!ratings.containsKey(key+""))
			{
				unwatchedMovie.add(key);
			}
			else
				watched.add(key+"");
		}
		//System.out.println(watched.size());
		for(Integer key:unwatchedMovie)
		{
			Map<String,Double> simi= getHybridRecommendatin(key+"");
			double prod=1.0;
			double sum =0,result=0;
			for(String s: watched)
			{
				//System.out.println(s);
				Double rat =ratings.getOrDefault(s, 2.0);
				Double wm=simi.getOrDefault(s, 0.1);
				prod=prod+rat*wm;
				sum+=wm;
			}
			if(sum!=0)
			{
				result=prod/sum;
			}else
			{
				
				result=0;
			}
			if(result>=5.0)
				result=0;
			predicted.put(key+"", result);
			
		}
		predicted=sortByValue(predicted);
		for(String ss : predicted.keySet())
		{
			System.out.println(getMName(Integer.parseInt(ss))+"aaa"+predicted.get(ss));
		}
		return predicted;
	}
	
	public boolean imageExists(String path)
	{
		File tmpDir = new File(path);
		return (tmpDir.exists());
	
	}
}
