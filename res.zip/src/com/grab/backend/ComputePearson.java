package com.grab.backend;
//1 Converts user ratings file into m X m rating matrix

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeSet;

import com.grab.database.DataB;

public class ComputePearson{
	static DataB db;
	public ComputePearson()
	{
	
		
	}
	public static void buildSimilarityMatrix() {
		db = new DataB();
			TreeSet<String> userNames=new TreeSet<>();
	        TreeSet<String> itemNames=new TreeSet<>();
	        String userlist,movielist;
	        double ratinglist;
	        List<String[]> lines = new ArrayList<String[]>();
	        Map< String,Map<String,Double>> dataMap=new HashMap<>();
			
				 
			
				     lines = db.getMoviebyRatings();
				    // System.out.println(lines.get(4)[0]+"a"+lines.get(4)[1]+"b"+lines.get(4)[2]);
				     
				     for(int i=0;i<lines.size();i++)
				     {
				     userlist=lines.get(i)[0];
				     movielist = lines.get(i)[1];
				     ratinglist = Double.parseDouble(lines.get(i)[2]);
				     
		            userNames.add(userlist);
		            itemNames.add(movielist);
		            
		            Map<String,Double> map=dataMap.getOrDefault(userlist, new HashMap<>());
		            map.put(movielist, ratinglist);
		            dataMap.put(userlist, map);
		        }
		       String[] usermat=new String[userNames.size()];
		       String[][] ratingmat = new String[userNames.size()][itemNames.size()];
		      /*  for(String itemName:itemNames){
		           System.out.print("\t"+itemName);
		           
		        }*/
		      // System.out.println();
		        
		        int a=0,b=0;
		       for(String userName:userNames){
		    	 
		    	   b=0;
		            //System.out.print(userName);
		            
		            for(String itemName:itemNames){
		            	
		                Map<String,Double> map=dataMap.getOrDefault(userName, new HashMap<>());
		                Double rate=map.getOrDefault(itemName, -1.0);
		                String str= ((double)rate==-1)? "-1":String.valueOf(rate);
		                //System.out.print("\t"+str);
		                ratingmat[a][b]=str;
		                b++;
		            }
		           // System.out.println("");
		           
		            a++;
		       }
		        	System.out.println("Doneq");
			
		  double sum=0;
		  List<Double> avg = new ArrayList<Double>();
		   		for(int i=1;i<lines.size();i++) {
		   			for(int j=1;j<lines.get(i).length;j++) {
		   				if(!lines.get(i)[j].equals("-1"))
		   					sum+=Double.parseDouble(lines.get(i)[j]);
		   			}
		   			try {
		   				avg.add(sum/(lines.get(i).length-2));
		   			}
		   			catch(Exception e)
		   			{
		   				avg.add((double) 0);
		   			}		
		   		}
		   		int rows=userNames.size();
		   		int cols =itemNames.size();
		   		ArrayList<ArrayList<String>> mov = new ArrayList<ArrayList<String>>(cols-1);
		   		for(int i=0;i<cols;i++)
		   		{
		   		mov.add(i,new ArrayList<String>());
		   		
		   		}
		   		rows=ratingmat.length;
		   		cols=ratingmat[1].length;
		   		
		   		for(int i=0;i<ratingmat[1].length;i++)
		   		{
		   			for(int j=0;j<ratingmat.length;j++)
		   			{
		   				mov.get(i).add(ratingmat[j][i]);
		   			}
		   		}
		   		
		   		double[][] pearson = new double[cols-1][cols-1];
		   		System.out.println(rows);
		   		int count=1;
		   		for(int i=0;i<cols-1;i++)
		   		{
		   			
		   		for(int j=0;j<cols-1;j++)
		   		{
		   			if(Integer.parseInt(lines.get(i)[1]) <=143 && Integer.parseInt(lines.get(j)[1])<=143)
		   			{
		   			if(i==j)
		   				pearson[i][j]=1;
		   			else if(i>j)
		   				pearson[i][j]=pearson[j][i];
		   			else
		   				pearson[i][j]=getPersonCoeffecient(mov.get(i),mov.get(j),avg);
		   			System.out.println(pearson[i][j]);
		   			if(db.addPearson(count, lines.get(i)[1], lines.get(j)[1], pearson[i][j]))
					{
						count++;
					}
					else
					{
						System.out.println("Failed Miserably");
					}
		   			}
		   		}
		   	}


		   	
		   
	} 
		
	public static double getPersonCoeffecient(ArrayList<String> m1,ArrayList<String> m2,List<Double> avg)
   	{
   		double val=0,prod=0, det0 = 1;
   		double det1=0,det2=0;
   		for(int i=0;i<m1.size();i++)
   		{
   			double mm2 = Double.parseDouble(m2.get(i));
   			double mm = Double.parseDouble(m1.get(i));
   			if(mm==-1 || mm2==-1)
   				continue;
   			else
   			{
   			//	System.out.println(avg.get(i));
   				mm=mm-avg.get(i);
   				mm2=mm2-avg.get(i);
   				prod=prod+Math.abs(mm*mm2);
   				det1=det1+mm*mm;
   				det2=det2+mm2*mm2;
   			}
   		}
   		det0 = Math.sqrt(det1*det2);
   		try {
   		val=prod/det0;
   		val=Double.parseDouble(new DecimalFormat("##.###").format(val));
   		}
   		catch(Exception e){
   			val=0;
   		}
   		return val;
   	}
public static void main(String[] args)
{
	buildSimilarityMatrix();
	
}
}
