package com.grab.backend;
// I used to give content based similarity to the movies
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeSet;

import com.grab.database.DataB;

public class ComputeContentSimilarity {
	public static BufferedReader br;
	public static BufferedWriter bw;
	static DataB db;
	 static List<String[]> lines;
	public static void computeSimilarity()
	{
		
			 db= new DataB();
			
			lines  = db.getMovieDetails();
			int rows = lines.size();
			int cols = lines.get(1).length;
			
			System.out.println("rows="+rows);
			System.out.println("cols="+cols);
			for(int i=0;i<8;i++)
			{
				System.out.println(lines.get(1)[i]);
			}
	
			double[][] aray =new double[rows][rows];
			double r=0;
			for(int i=0;i<rows;i++)
			{

				for(int j=i;j<rows;j++)
				{
					try {
					if(i<j)
					{
						
						 r= calculateSimilarity(lines.get(i),lines.get(j));
						aray[i][j]=r;
						aray[j][i]=r;
					}
					
					else
						aray[i][j]=0;
					
						}catch (Exception e) {
							
							e.printStackTrace();
						}
				}
					
					
			}
			
			System.out.println("Done here");
			int count=1;
			double[][] cosine = new double[rows][rows];
			for(int i=0;i<aray.length;i++)
			{
				
			for(int j=0;j<aray.length;j++)
			{
				
				if(i==j)
					cosine[i][j]=1;
				else if(i>j)
					cosine[i][j]=cosine[j][i];
				else
					cosine[i][j]=getCosineValue(aray[i],aray[j]);
				System.out.println(cosine[i][j]);
				if(db.addCosine(count, lines.get(i)[0], lines.get(j)[0], cosine[i][j]))
				{
					count++;
				}
				else
				{
					System.out.println("Failed Miserably");
				}
			}
			}
			System.out.println("i m done");
			
		         
			        
	}
				
			
	

	
	public static double calculateSimilarity(String[] m1,String[] m2)
	{
		double sim=0;
		//System.out.println(m1[1]+m1[2]+m1[3]+m1[4]+m1[5]);
		sim=sim+calcuateTitleSimilarity(m1[1],m2[1]);

		sim=sim+calcuateGenreSimilarity(m1[2],m2[2]);
		
		
		sim=sim+calcuateCountrySimilarity(m1[5],m2[5]);

		sim=sim+calcuateLanguageSimilarity(m1[3],m2[3]);
		
		sim=sim+calcuateDateSimilarity(m1[4],m2[4]);
		
		sim=Double.parseDouble(new DecimalFormat("##.###").format(sim));
		
		return sim;
	}
	
	
	
	
	
	
	
	public static double calcuateGenreSimilarity(String m1,String m2)
	{
		int gen=0;
		double sum=0;
		try {
		for(int i=1;i<17;i++)
		{
			if(m1.charAt(i)==m2.charAt(i))
			{
				if(m1.charAt(i)=='1')
				gen++;
			}
		}
		if(gen>4)
		sum=4;
		else
			sum=gen;
		
		
		}
		catch(Exception e)
		{
			sum=0;
		}
		System.out.println("genre="+sum);
		return sum;
	}
	
	
	
	
	public static double calcuateTitleSimilarity(String m1,String m2)
	{
		String[] st1=null,st2=null;
		double tit=0;
		//System.out.println(m1+""+m2);
		st1=m1.split(" ");
		st2=m2.split(" ");
		for(String x: st1)
		{
			for(String y: st2)
			{
				if(x.equals(y))
				{
					tit++;
				}
			}
		}
		int sum=st1.length+st2.length;
	
		try{tit=tit/(sum-tit)*2;}
		catch(Exception e)
		{
			tit=0;
		}
		System.out.println(m1+" "+m2+" "+tit);
		return tit;
	}
	
	
	public static double calcuateCountrySimilarity(String m1,String m2)
	{
		String[] st1=null,st2=null;
		double cont=0;
		try{
		
	//	System.out.println(m1+""+m2);
		
		st1=m1.split("[+]");
		
		st2=m2.split("[+]");
		
		for(String x: st1)
		{
			for(String y: st2)
			{
				
				if(x.equals(y))
				{
					cont++;
				}
			}
		}
		int sum=st1.length+st2.length;
	//	System.out.println(sum);
		cont=cont/(sum-cont)*1;
		}
		catch(Exception e)
		{
			cont=0;
		}
		System.out.println("Cont="+cont);
		return cont;
	}
	public static int calcuateLanguageSimilarity(String m1,String m2)
	{
		
		if(m1.equals(m2))
		{
		return 1;	
		}
		else 
		return 0;
	}
	public static int calcuateDateSimilarity(String m1,String m2)
	{
		Double d1=Double.parseDouble(m1);
		Double d2 = Double.parseDouble(m2);
		
		if((d1-d2<5) || (d2-d1<5))
		{

			System.out.println("date="+1);
			return 1;
		}
		else {
			System.out.println("date="+0);
			return 0;
		}
	}

	public static double getCosineValue(double[] m1,double[] m2)
	{
		double val=0,prod=0;
		double det0 = 1,det1=0,det2=0;
		for(int i=0;i<m1.length;i++)
		{
			double mm2 = m2[i];
			double mm = m1[i];
			prod=prod+Math.abs(mm*mm2);
			det1=det1+mm*mm;
			det2=det2+mm2*mm2;
			
		}
		det0 = Math.sqrt(det1*det2);
		try {
		val=prod/det0;
		val=Double.parseDouble(new DecimalFormat("##.###").format(val));
	
		}
		catch(Exception e){
			val=0;
		}
		System.out.println("cosineval="+val);
		return val;	
	}
	
	
	
public static void main(String[] args) {
		
		computeSimilarity();
	}
	
}
