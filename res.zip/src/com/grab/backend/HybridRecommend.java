package com.grab.backend;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import com.grab.database.DataB;

public class HybridRecommend {

	public static void main(String[] args) {
			DataB db = new DataB();
		try {
			
			List<String[]> cont = db.getCosine();
			List<String[]> colab = db.getPearson();
			
			int rows = cont.size();
			int cols = cont.get(0).length;
			  System.out.println(rows);
			  System.out.println(cols);
			  System.out.println(colab.size());
			double hyb=0;
			int i=0;
			int j=0;
			int count=1;
			for(i=0;i<rows;i++)
			{
				for(j=0;j<rows;j++)
				{
					if(cont.get(i)[0]==colab.get(i)[0] )
					{
						if(cont.get(i)[1]==colab.get(j)[1])
						{
							if(Double.parseDouble(colab.get(i)[2])!=1 || Double.parseDouble(colab.get(i)[2])!=0)
								hyb=Double.parseDouble(cont.get(i)[2])+Double.parseDouble(colab.get(i)[2])/2;
							
						}
					}
					
					
				}
				if(j==rows)
				{
					hyb=Double.parseDouble(cont.get(i)[2]);
				}
				//System.out.println(cont.get(i)[0]+"b"+cont.get(i)[1]+"a"+hyb);
				if(db.addHybrid(count, cont.get(i)[0], cont.get(i)[1],hyb))
					count++;
				else
					System.out.println("Failed Miserably");
				
			}
		}
		catch(Exception e)
		{
			
		}

	}

}
