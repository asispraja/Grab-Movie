package com.grab.frontend;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.UIManager;
import javax.swing.border.BevelBorder;
import javax.swing.border.EmptyBorder;

import com.grab.database.DataB;

public class Signup extends JFrame {
	

	private JPanel contentPane;
	private JTextField email2;
	private JPasswordField passwordField;
	private JTextField txtLogin;
	private JTextField txtClose;
	private JLabel lblNewLabel_1;
	private JLabel lblNotAMembersign;
	private JLabel lblNewLabel;
	private JLabel label;
	private DataB database;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		}
		
		catch(Exception e)
		{
			//handlels exception
			
		}
		
		
		
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Signup frame = new Signup();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Signup() {
		//setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		database = new DataB();
		setBounds(400, 200, 629, 309);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(153, 0, 153));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		email2 = new JTextField("");
		email2.setFont(new Font("Tahoma", Font.PLAIN, 15));
		email2.setForeground(new Color(75, 0, 130));
		email2.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		email2.setBounds(210, 81, 260, 32);
		contentPane.add(email2);
		email2.setColumns(10);
		
		
		
		label = new JLabel("");
		label.setIcon(new ImageIcon("res/image/pass.png"));
		label.setBounds(180, 139, 32, 32);
		contentPane.add(label);
		
		passwordField = new JPasswordField();
		passwordField.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		passwordField.setBounds(210, 139, 260, 32);
		contentPane.add(passwordField);
		
		txtLogin = new JTextField();
		txtLogin.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				String pass = new String(passwordField.getPassword());
				String user = email2.getText();
					
						try {
								if(database.register(user, pass))
									LoginPage.main(null);
							
						
					
							}catch(Exception a) {
								System.out.println("Error in connection");
								}
				
					
			}
		});
		
		
		lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon("res/image/userimage.png"));
		lblNewLabel.setBounds(180, 81, 32, 32);
		contentPane.add(lblNewLabel);
		txtLogin.setForeground(Color.WHITE);
		txtLogin.setFont(new Font("Tahoma", Font.PLAIN, 18));
		txtLogin.setHorizontalAlignment(SwingConstants.CENTER);
		txtLogin.setText("SIGNUP");
		txtLogin.setBorder(new BevelBorder(BevelBorder.RAISED, null, null, null, null));
		txtLogin.setOpaque(false);
		txtLogin.setEditable(false);
		txtLogin.setColumns(10);
		txtLogin.setBounds(180, 226, 126, 26);
		contentPane.add(txtLogin);
		
		txtClose = new JTextField();
		txtClose.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				dispose();
			}
		});
		
		lblNotAMembersign = new JLabel("Already a member? Login here");
		lblNotAMembersign.setForeground(new Color(255, 255, 255));
		lblNotAMembersign.setFont(new Font("Tahoma", Font.PLAIN, 17));
		lblNotAMembersign.setBounds(180, 192, 290, 20);
		contentPane.add(lblNotAMembersign);
		txtClose.setForeground(Color.WHITE);
		txtClose.setFont(new Font("Tahoma", Font.PLAIN, 18));
		txtClose.setHorizontalAlignment(SwingConstants.CENTER);
		txtClose.setText("CLOSE");
		txtClose.setBorder(new BevelBorder(BevelBorder.RAISED, null, null, null, null));
		txtClose.setOpaque(false);
		txtClose.setEditable(false);
		txtClose.setColumns(10);
		txtClose.setBounds(340, 226, 126, 26);
		contentPane.add(txtClose);
		
		lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setBorder(new BevelBorder(BevelBorder.RAISED, null, null, null, null));
		lblNewLabel_1.setIcon(new ImageIcon("res/image/logowala.png"));
		lblNewLabel_1.setBounds(0, 0, 629, 309);
		contentPane.add(lblNewLabel_1);
		setUndecorated(true);
	}
}
