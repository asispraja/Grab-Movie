package com.grab.frontend;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

import com.grab.backend.Search;
import com.grab.backend.ShowRecommendation;
import com.grab.database.DataB;

import javax.swing.JScrollPane;
import javax.swing.ScrollPaneConstants;
// TODO write  an arraylist to get the movie id and movie name 
public class RecommendationPaage extends JFrame {
	ShowRecommendation recommendation = new ShowRecommendation();
	private JPanel contentPane;
	private JTextField searchField;
	private JLabel txtSearch;
	private static String username="100";
	JPanel mypanel= new JPanel();
	List<JLabel>recom = new ArrayList<JLabel>();
	String ss=null;
	JLabel selectedM;
	DataB db= null;
	int j=0;
	List<String> searcheditem= new ArrayList<String>();
	List<Integer> result = null;
	//String[] s= {"1","10","1011","1016","1022","1028","1029","1030","1031","1032","1033","1035","1036","104"};
//	List<Integer> recommendeds= new ArrayList<Integer>();
	List<String> recommendeds =
            new ArrayList<String>(Arrays.asList("100042", "2", "3", "4", "5","6","7","8","9","10","11","12"));
	Map<Integer,String > movie = new LinkedHashMap<Integer,String>();
	/**
	 * Launch the a	lication.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					
					RecommendationPaage frame = new RecommendationPaage();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	
	public void loadMovie()
	{
		movie= db.getMovie();
		
	}

	
	public RecommendationPaage() {
		db = new DataB();
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(0, 0, 1366, 768);
		System.out.println("staaaaart");
		loadMovie();
		
		
		System.out.println("ready");
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		for(int m=0;m<12;m++)
			recom.add(new JLabel());
		draw();
		
		JLabel lblTreanding = new JLabel("Trending");
		lblTreanding.setBounds(48, 172, 276, 44);
		lblTreanding.setHorizontalAlignment(SwingConstants.CENTER);
		lblTreanding.setForeground(Color.WHITE);
		lblTreanding.setFont(new Font("Arial Black", Font.PLAIN, 26));
		lblTreanding.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				Trending.setUser(username);
				Trending.main(null);
				dispose();
			}
		});
		contentPane.add(lblTreanding);
		 
		 JScrollPane scrollPane = new JScrollPane();
		 scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
		 scrollPane.setBounds(410, 343, 876, 375);
		 contentPane.add(scrollPane);
		
		 
		 mypanel.setLayout(new GridLayout(0,6));
		 scrollPane.setViewportView(mypanel);
		
		
		JLabel label_2 = new JLabel("");
		label_2.setBounds(0, 182, 362, 34);
		label_2.setIcon(new ImageIcon("res/image/line.png"));
		contentPane.add(label_2);
		
		JLabel label_5 = new JLabel("");
		label_5.setBounds(0, 507, 362, 34);
		label_5.setIcon(new ImageIcon("res/image/line.png"));
		contentPane.add(label_5);
		
		JLabel label_4 = new JLabel("");
		label_4.setBounds(0, 442, 362, 34);
		label_4.setIcon(new ImageIcon("res/image/line.png"));
		contentPane.add(label_4);
		
		JLabel label_3 = new JLabel("");
		label_3.setBounds(0, 237, 362, 34);
		label_3.setIcon(new ImageIcon("res/image/line.png"));
		contentPane.add(label_3);
		
		JLabel label_1 = new JLabel("");
		label_1.setBounds(0, 126, 362, 34);
		label_1.setIcon(new ImageIcon("res/image/line.png"));
		contentPane.add(label_1);
		
		JLabel label = new JLabel("");
		label.setBounds(10, 11, 1355, 730);
		label.setIcon(new ImageIcon("res/image/homepage123.png"));
		contentPane.add(label);
	}
	
	

	private void draw() {
		
		
		recommendedMovie();
		JLabel lblRecommendedForYou = new JLabel("Selected Movies:");
		lblRecommendedForYou.setBounds(394, 84, 238, 14);
		lblRecommendedForYou.setFont(new Font("Tahoma", Font.BOLD, 11));
		contentPane.add(lblRecommendedForYou);
		
		selectedM = new JLabel("HIIIIIII");
		selectedM.setIcon(new ImageIcon("data/finalimage/"+db.getMName(100017)+".jpg"));
		selectedM.setBounds(394, 109, 127, 183);
		selectedM.setVisible(false);
		
		JLabel lblNewLabel = new JLabel("Home");
		lblNewLabel.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				MainPage.setUser(username);
				MainPage.main(null);
				dispose();
			}
		});
		lblNewLabel.setBounds(38, 117, 276, 44);
		lblNewLabel.setForeground(Color.WHITE);
		lblNewLabel.setFont(new Font("Arial Black", Font.PLAIN, 26));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		contentPane.add(lblNewLabel);
		
		
		
		JLabel lblPopular = new JLabel(" Recommendation");
		lblPopular.setBounds(38, 227, 324, 44);
		lblPopular.setHorizontalAlignment(SwingConstants.CENTER);
		lblPopular.setForeground(Color.RED);
		lblPopular.setFont(new Font("Arial Black", Font.PLAIN, 26));
		contentPane.add(lblPopular);
		
		
		JLabel lblHistory = new JLabel("LIBRARY");
		lblHistory.setBounds(38, 331, 276, 44);
		lblHistory.setHorizontalAlignment(SwingConstants.CENTER);
		lblHistory.setForeground(Color.WHITE);
		lblHistory.setFont(new Font("Arial Black", Font.PLAIN, 26));
		contentPane.add(lblHistory);
		
		JLabel lblHistory_1 = new JLabel("History");
		lblHistory_1.setBounds(60, 432, 276, 44);
		lblHistory_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblHistory_1.setForeground(Color.WHITE);
		lblHistory_1.setFont(new Font("Arial Black", Font.PLAIN, 26));
		lblHistory.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				History.setUser(username);
				History.main(null);
				dispose();
			}
		});
		contentPane.add(lblHistory_1);
		
		JLabel lblLikedVideos = new JLabel("Liked Videos");
		lblLikedVideos.setBounds(70, 497, 276, 44);
		lblLikedVideos.setHorizontalAlignment(SwingConstants.CENTER);
		lblLikedVideos.setForeground(Color.WHITE);
		lblLikedVideos.setFont(new Font("Arial Black", Font.PLAIN, 26));
		lblLikedVideos.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				Liked.setUser(username);
				Liked.main(null);
				dispose();
			}
		});
		contentPane.add(lblLikedVideos);
		contentPane.add(selectedM);
		
		JLabel lblTopTrending = new JLabel("Recommendations:");
		lblTopTrending.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblTopTrending.setBounds(394, 300, 238, 14);
		contentPane.add(lblTopTrending);
		
		System.out.println("HI");
		searchField= new JTextField();
		searchField.setBounds(509, 22, 738, 27);
		contentPane.add(searchField);
		searchField.setColumns(10);
		
		txtSearch = new JLabel();
		txtSearch.setBounds(1248, 22, 70, 27);
		txtSearch.setHorizontalAlignment(SwingConstants.CENTER);
		txtSearch.setText("Select");
		txtSearch.addMouseListener(new MouseAdapter(){
			@Override
			public void mouseClicked(MouseEvent e) {
				String search= searchField.getText();
				searcheditem=Search.searched(search);
				recommendeds.clear();
				
				for(String s: searcheditem)
				{
					recommendeds.add(db.getMid(s));
				}
				
				draw();
			}
			
		});
		
		
		contentPane.add(txtSearch);
		
		
	}

	private void recommendedMovie() {
		
		int recomX=394;
		int recomY=338;
		int m=0;
		
		
		for(String ss: recommendeds)
		{
			
			if(m==12)
				break;
		//System.out.println(getMName(ss));
		//System.out.println(ss);
		
		recom.get(m).setIcon(new ImageIcon("data/finalimage/"+db.getMName(Integer.parseInt(ss))+".jpg"));
		recom.get(m).setBounds(recomX, recomY, 127, 183);
		recom.get(m).addMouseListener(new MouseAdapter()
		{
				@Override
				public void mouseClicked(MouseEvent arg0) {
					//System.out.println("a"+recommendeds.size());
					recommendeds.clear();
					
					//System.out.println("x"+recommendeds.size());
					String path="data/finalimage/"+db.getMName(Integer.parseInt(ss))+".jpg";
					selectedM.setIcon(new ImageIcon(path));
					if(db.imageExists(path))
						selectedM.setIcon(new ImageIcon(path));
						else
						{
							selectedM.setIcon(new ImageIcon("data/finalimage/"+"Nothumb"+".jpg"));
						}
					selectedM.setVisible(true);
					System.out.println("pugyo");
					recommendeds=db.getRankedHybridRecommendation(ss+"");
					recommendedMovie();
					//System.out.println("z"+recommendeds.size());
				}
			
		});
		mypanel.add(recom.get(m));
		m++;
		
		
		}
		
	}
	public static void setUser(String x) {
		username=x;
		// TODO Auto-generated method stub
		
	}
	
}
