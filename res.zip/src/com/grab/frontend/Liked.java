package com.grab.frontend;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

import com.grab.database.DataB;

import javax.swing.ScrollPaneConstants;
import java.awt.GridLayout;

public class Liked extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField txtSearch;
	private static String username="10";
	JScrollPane scrollPane=new JScrollPane();
	//private Map watched=null;
	private Map<String,Double> recommended= new HashMap<String,Double>();
	List<String > movie = new ArrayList<String>();	
	private List<String> userRec = null;
	private DataB db;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Liked frame = new Liked();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Liked() {
		db = new DataB();
	loadMovie();	
	draw();	
	}
	public void loadMovie()
	{
		try {
		movie = db.getLiked(username);
		}catch(Exception e)
		{
			System.out.println("hello");
		}
		
	}
		
		public void draw()
		{
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(0, 0, 1366, 768);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblHiUser = new JLabel("Hi "+username);
		lblHiUser.setBounds(1265, 28, 46, 14);
		contentPane.add(lblHiUser);
		JLabel lblTopTrending = new JLabel("Top Trending");
		
		lblTopTrending.setBounds(394, 100,165,25);
		contentPane.add(lblTopTrending);
		lblTopTrending.setFont(new Font("Tahoma", Font.BOLD, 20));
		
		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
		scrollPane_1.setBounds(394, 150, 917, 638);
		contentPane.add(scrollPane_1);
		
		JPanel panel = new JPanel();
		scrollPane_1.setColumnHeaderView(panel);
		panel.setLayout(new GridLayout(0, 5));
		
		List<JLabel> trending= new ArrayList<JLabel>();
		for(int i=0;i<movie.size();i++)
		{
			trending.add(new JLabel());
		}
		int index=0;
		
		for(JLabel trend: trending)
		{
		
		panel.add(trend);
		
		String mm=movie.get(index);
		System.out.println(mm+"xxxx"+db.getMName(Integer.parseInt(mm)));
		String path="data/finalimage/"+db.getMName(Integer.parseInt(mm))+".jpg";
		if(db.imageExists(path))
		trend.setIcon(new ImageIcon(path));
		else
		{
			trend.setIcon(new ImageIcon("data/finalimage/"+"Nothumb"+".jpg"));
		}
		
			
		trend.addMouseListener(new MouseAdapter()
				{
				@Override
				public void mouseClicked(MouseEvent arg0) {
					Description.setMovie(mm);
					Description.setUser(username);
					Description.main(null);
				
				
				}
				});
		index++;
		}
		textField = new JTextField();
		textField.setBounds(394, 22, 674, 27);
		contentPane.add(textField);
		textField.setColumns(10);
		
		txtSearch = new JTextField();
		txtSearch.setBounds(1065, 22, 70, 27);
		txtSearch.setHorizontalAlignment(SwingConstants.CENTER);
		txtSearch.setText("Search");
		contentPane.add(txtSearch);
		txtSearch.setColumns(10);
		
		JLabel lblTreanding = new JLabel("Trending");
		lblTreanding.setBounds(48, 172, 276, 44);
		lblTreanding.setHorizontalAlignment(SwingConstants.CENTER);
		lblTreanding.setForeground(Color.RED);
		lblTreanding.setFont(new Font("Arial Black", Font.PLAIN, 26));
		lblTreanding.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				Trending.setUser(username);
				Trending.main(null);
				dispose();
			}
		});
		contentPane.add(lblTreanding);
		
		JLabel label_2 = new JLabel("");
		label_2.setBounds(0, 182, 362, 34);
		label_2.setIcon(new ImageIcon("res/image/line.png"));
		contentPane.add(label_2);
		
		JLabel lblNewLabel = new JLabel("Home");
		lblNewLabel.setBounds(38, 117, 276, 44);
		lblNewLabel.setForeground(Color.WHITE);
		lblNewLabel.setFont(new Font("Arial Black", Font.PLAIN, 26));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		contentPane.add(lblNewLabel);
		
		JLabel lblPopular = new JLabel("AI Recommendation");
		lblPopular.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				RecommendationPaage.setUser(username);
				RecommendationPaage.main(null);
				dispose();
			}
		});
		lblPopular.setBounds(38, 227, 324, 44);
		lblPopular.setHorizontalAlignment(SwingConstants.CENTER);
		lblPopular.setForeground(Color.WHITE);
		lblPopular.setFont(new Font("Arial Black", Font.PLAIN, 26));
		
		contentPane.add(lblPopular);
		
		
		JLabel lblHistory = new JLabel("LIBRARY");
		lblHistory.setBounds(38, 331, 276, 44);
		lblHistory.setHorizontalAlignment(SwingConstants.CENTER);
		lblHistory.setForeground(Color.WHITE);
		lblHistory.setFont(new Font("Arial Black", Font.PLAIN, 26));
		contentPane.add(lblHistory);
		
		JLabel lblHistory_1 = new JLabel("History");
		lblHistory_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				History.setUser(username);
				History.main(null);
				dispose();
			}
			
		});
		lblHistory_1.setBounds(60, 432, 276, 44);
		lblHistory_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblHistory_1.setForeground(Color.WHITE);
		lblHistory_1.setFont(new Font("Arial Black", Font.PLAIN, 26));
		contentPane.add(lblHistory_1);
		
		JLabel lblLikedVideos = new JLabel("Liked Videos");
		lblLikedVideos.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				//dispose();
			}
			
		});
		lblLikedVideos.setBounds(70, 497, 276, 44);
		lblLikedVideos.setHorizontalAlignment(SwingConstants.CENTER);
		lblLikedVideos.setForeground(Color.WHITE);
		lblLikedVideos.setFont(new Font("Arial Black", Font.PLAIN, 26));
		contentPane.add(lblLikedVideos);
		
		JLabel label_5 = new JLabel("");
		label_5.setBounds(0, 507, 362, 34);
		label_5.setIcon(new ImageIcon("res/image/line.png"));
		contentPane.add(label_5);
		
		JLabel label_4 = new JLabel("");
		label_4.setBounds(0, 442, 362, 34);
		label_4.setIcon(new ImageIcon("res/image/line.png"));
		contentPane.add(label_4);
		
		JLabel label_3 = new JLabel("");
		label_3.setBounds(0, 237, 362, 34);
		label_3.setIcon(new ImageIcon("res/image/line.png"));
		contentPane.add(label_3);
		
		JLabel label_1 = new JLabel("");
		label_1.setBounds(0, 126, 362, 34);
		label_1.setIcon(new ImageIcon("res/image/line.png"));
		contentPane.add(label_1);
		
		JLabel label = new JLabel("");
		label.setBounds(10, 0, 1355, 730);
		label.setIcon(new ImageIcon("res/image/homepage123.png"));
		contentPane.add(label);
		
	}

	public static void setUser(String x) {
		username=x;
		// TODO Auto-generated method stub
		
	}
}





